from enum import Enum


class Routes(str, Enum):
    OBJECTS = '/issues'
    OBJECTS_ITEM = '/issues/{}'

    def __str__(self) -> str:
        return self.value
